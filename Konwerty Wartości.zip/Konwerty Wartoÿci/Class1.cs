﻿using System;
using System.Collections.Generic;
using System.IO;

public class ColorP1ToColorEnConverter : IValueConverter
{
	public Convert(object v,Type targetType, object parameter, System.Globalization.CultureInfo culture)
	{
		if(targetType != typeof(Brush))
		{
			throw new ArgumentException("Celem powinien być typ Brush");
		}
		string colorPl = v.ToString();
		Dictionary<string, Brush> color = new Directory<string, Brush>();
		color.Add("Czarny", Brushes.Black);
		color.Add("Czernowy", Brushes.Red);
		color.Add("Żułty", Brushes.Yellow);
		color.Add("Zielony", Brushes.Green);
        color.Add("Niebieski", Brushes.Blue);
		if (color.ContainsKay(colorPL)) return color[colorPl];
		else return Brushes.LightGreen;

	}
	public Object ConvertBack(object v, Type targetType, object parameter, System.Globalization.CultureInfo culture)
	{
		throw new NotImplementedException(); 
	}
}
